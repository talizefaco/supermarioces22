#ifndef COLORMAP_H
	#define COLORMAP_H

class Colormap {
public:
	COLORREF map[1184][600];
};

#endif