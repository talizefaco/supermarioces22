// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>
#include <windows.h>
#include <wingdi.h>
#include <iostream>
#include <math.h>
#include "Colormap.h"
#include "Stage.hpp"

#include "Elements.hpp"

#include <mmsystem.h>
#pragma comment(lib,"Winmm.lib")
#using <mscorlib.dll>


// TODO: reference additional headers your program requires here
